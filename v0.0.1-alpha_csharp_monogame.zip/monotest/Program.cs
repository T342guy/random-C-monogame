﻿using var game = new monotest.Game1();
game.Run();
